# Methods for Each Page
SchoologyPage (shared methods)
* constructor
* addCheckmarks - adds checkmarks at first for calling
* getAsgmtByName: String -> DOMEl
* createGreenHighlightEl - returns a DOMEl to inject over assignment
* updateCourses -> updateStorage


Each Page (eg CalendarPage)
* constructor
* j_check

